</div>
    </form>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" type="text/javascript"></script>
    <script src="script.js" type="text/javascript"></script>
</body>
<div id="cursor"></div>

</html>